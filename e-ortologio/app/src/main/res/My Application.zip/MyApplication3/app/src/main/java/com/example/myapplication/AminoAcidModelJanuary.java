package com.example.myapplication;

public class AminoAcidModelJanuary {


    String month;
    String names;
    int images;


    public AminoAcidModelJanuary(String month, String names, int images) {
        //this.days = days;
        this.month = month;
        this.names = names;
        this.images = images;
    }

    public String getMonth() {
        return month;
    }

    public String getNames() {
        return names;
    }

    public int getImages() {
        return images;
    }

}



