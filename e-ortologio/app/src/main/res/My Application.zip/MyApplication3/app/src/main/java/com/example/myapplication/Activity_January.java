package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Activity_January extends AppCompatActivity {


    ArrayList<AminoAcidModelJanuary> aminoAcidModelJanuary = new ArrayList<>();

    int[] aminoAcidImages = {R.drawable.ic_baseline_today_24};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_january);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerViewJanuary);

        setAminoAcidModelJanuary();

        AA_RecyclerViewAdapterJanuary adapterJanuary = new AA_RecyclerViewAdapterJanuary(this,aminoAcidModelJanuary);

        recyclerView.setAdapter(adapterJanuary);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setAminoAcidModelJanuary(){


        String[] aminoAcidMonthsJanuary = getResources().getStringArray(R.array.months_txt);
        String[] aminoAcidNamesJanuary = getResources().getStringArray(R.array.names_january_txt);


        for( int i=0; i<31; i++){

            aminoAcidModelJanuary.add(new AminoAcidModelJanuary(i+1 + " " + aminoAcidMonthsJanuary[0],aminoAcidNamesJanuary[i],aminoAcidImages[0]));

        }

    }
}