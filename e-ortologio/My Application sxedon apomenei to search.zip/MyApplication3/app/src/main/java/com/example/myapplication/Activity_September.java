package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Activity_September extends AppCompatActivity {


    ArrayList<AminoAcidModel> aminoAcidModels = new ArrayList<>();

    int[] aminoAcidImages = {R.drawable.ic_baseline_today_24};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_september);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerViewSeptember);

        setAminoAcidModel();

        AA_RecyclerViewAdapterSeptember adapter = new AA_RecyclerViewAdapterSeptember(this,aminoAcidModels);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setAminoAcidModel(){

        String[] aminoAcidMonths = getResources().getStringArray(R.array.months_txt);
        String[] aminoAcidNames = getResources().getStringArray(R.array.names_September_txt);
        String[] aminoAcidDayoffs = getResources().getStringArray(R.array.dayoff_September_txt);
        String n_day = "";

        for( int i=0; i<30; i++){

            if(i%7==0) n_day="Παρασκευή ";
            if(i%7==1) n_day="Σάββατο ";
            if(i%7==2) n_day="Κυριακή ";
            if(i%7==3) n_day="Δευτέρα ";
            if(i%7==4) n_day="Τρίτη ";
            if(i%7==5) n_day="Τετάρτη ";
            if(i%7==6) n_day="Πέμπτη ";

            aminoAcidModels.add(new AminoAcidModel(n_day + (i+1) + " " + aminoAcidMonths[8],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));

        }

    }
}