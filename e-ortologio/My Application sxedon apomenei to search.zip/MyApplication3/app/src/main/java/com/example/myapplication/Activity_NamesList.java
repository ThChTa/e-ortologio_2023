package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Activity_NamesList extends AppCompatActivity {


    ArrayList<AminoAcidModel> aminoAcidModels = new ArrayList<>();

    int[] aminoAcidImages = {R.drawable.ic_baseline_today_24};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_names_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerViewNamesList);

        setAminoAcidModel();

        AA_RecyclerViewAdapterNamesList adapter = new AA_RecyclerViewAdapterNamesList(this,aminoAcidModels);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setAminoAcidModel(){

        int i;

        String[] aminoAcidMonths = getResources().getStringArray(R.array.months_txt);
        String[] aminoAcidNames = getResources().getStringArray(R.array.names_nameslist_txt);
        String[] aminoAcidDayoffs = getResources().getStringArray(R.array.dayoff_nameslist_txt);
        String n_day = "";

        for( i=0; i<365; i++){

            if(i%7==0) n_day="Κυριακή ";
            if(i%7==1) n_day="Δευτέρα ";
            if(i%7==2) n_day="Τρίτη ";
            if(i%7==3) n_day="Τετάρτη ";
            if(i%7==4) n_day="Πέμπτη ";
            if(i%7==5) n_day="Παρασκευή ";
            if(i%7==6) n_day="Σάββατο ";


if(i<31) aminoAcidModels.add(new AminoAcidModel(n_day + (i+1) + " " + aminoAcidMonths[0],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=31&&i<59) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-31) + " " + aminoAcidMonths[1],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=59&&i<90) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-59) + " " + aminoAcidMonths[2],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=90&&i<120) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-90) + " " + aminoAcidMonths[3],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=120&&i<151) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-120) + " " + aminoAcidMonths[4],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=151&&i<181) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-151) + " " + aminoAcidMonths[5],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=181&&i<212) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-181) + " " + aminoAcidMonths[6],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=212&&i<243) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-212) + " " + aminoAcidMonths[7],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=243&&i<273) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-243) + " " + aminoAcidMonths[8],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=273&&i<304) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-273) + " " + aminoAcidMonths[9],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=304&&i<334) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-304) + " " + aminoAcidMonths[10],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));
if(i>=334&&i<365) aminoAcidModels.add(new AminoAcidModel(n_day + ((i+1)-334) + " " + aminoAcidMonths[11],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));

        }

    }
}