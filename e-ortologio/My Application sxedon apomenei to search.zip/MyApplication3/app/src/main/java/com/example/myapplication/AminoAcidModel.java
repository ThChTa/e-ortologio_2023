package com.example.myapplication;

public class AminoAcidModel {


    String month;
    String names;
    String dayoff;
    int images;


    public AminoAcidModel(String month, String names,String dayoff, int images) {

        this.month = month;
        this.names = names;
        this.dayoff = dayoff;
        this.images = images;
    }

    public String getMonth() {
        return month;
    }

    public String getNames() {
        return names;
    }

    public String getDayoff() {
        return dayoff;
    }

    public int getImages() {
        return images;
    }

}



