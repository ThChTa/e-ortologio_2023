package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Activity_November extends AppCompatActivity {


    ArrayList<AminoAcidModel> aminoAcidModels = new ArrayList<>();

    int[] aminoAcidImages = {R.drawable.ic_baseline_today_24};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_november);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerViewNovember);

        setAminoAcidModel();

        AA_RecyclerViewAdapterNovember adapter = new AA_RecyclerViewAdapterNovember(this,aminoAcidModels);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setAminoAcidModel(){

        String[] aminoAcidMonths = getResources().getStringArray(R.array.months_txt);
        String[] aminoAcidNames = getResources().getStringArray(R.array.names_november_txt);
        String[] aminoAcidDayoffs = getResources().getStringArray(R.array.dayoff_november_txt);
        String n_day = "";

        for( int i=0; i<30; i++){

            if(i%7==0) n_day="Τετάρτη ";
            if(i%7==1) n_day="Πέμπτη ";
            if(i%7==2) n_day="Παρασκευή ";
            if(i%7==3) n_day="Σάββατο ";
            if(i%7==4) n_day="Κυριακή ";
            if(i%7==5) n_day="Δευτέρα ";
            if(i%7==6) n_day="Τρίτη ";

            aminoAcidModels.add(new AminoAcidModel(n_day + (i+1) + " " + aminoAcidMonths[10],aminoAcidNames[i],"Αργία : " + aminoAcidDayoffs[i],aminoAcidImages[0]));

        }

    }
}