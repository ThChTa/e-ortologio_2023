package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Button b3,b2,b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageView imgView = (ImageView)findViewById(R.id.imageView);
        imgView.setBackgroundResource(R.drawable.logo);

        view_one();


        //BUTTON CLICK OPEN NEW ACTIVITY FOR ACTIVITY_NAMES

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Activity_NamesList.class);
                startActivity(intent);
            }
        });


        //BUTTON CLICK OPEN NEW ACTIVITY FOR ACTIVITY_EORTOLOGIO

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Activity_Eortologio.class);
                startActivity(intent);
            }
        });


    }

    private void view_one(){
        b3 = findViewById(R.id.b3);
        b2 = findViewById(R.id.b2);
        b1 = findViewById(R.id.b1);
    }
}